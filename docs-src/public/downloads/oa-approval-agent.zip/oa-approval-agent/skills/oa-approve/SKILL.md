---
name: oa-approve
description: 对单条 OA 待审批项执行"同意"或"拒绝"操作，写入审批意见。
---

# oa-approve

调用 OA 系统的审批提交接口，对一条待办执行 approve / reject。

## 参数

| 参数 | 类型 | 必填 | 说明 |
|---|---|---|---|
| `todoId` | string | 是 | 待办 ID（来自 oa-todo-list 返回） |
| `action` | string | 是 | `approve` 或 `reject` |
| `memo` | string | 否 | 审批意见。建议带上自动处理标识，便于事后审计 |

## 返回

```json
{ "success": true,  "todoId": "...", "action": "approve" }
{ "success": false, "todoId": "...", "error": "..." }
```

## 脱敏说明

`https://your-oa.example.com/api/todo/submit` 是占位接口。
你公司的 OA 可能是 PUT、可能是 POST，字段名可能是 `decision` / `result` / `outcome`，
请按真实抓包结果替换。
