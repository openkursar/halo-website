// oa-approve — 对单条待办执行审批（脱敏示例）
//
// 模式 A：API 代理型。提交一次 POST，返回标准 success/error 结构。
//
// 把 your-oa.example.com、/api/todo/submit、字段名（todoId / decision / comment）
// 都替换成你公司 OA 的真实接口与字段。

async (params) => {
  const { todoId, action, memo = '' } = params || {}

  // 入参校验：早失败早返回，避免给 OA 发出无效请求
  if (!todoId) {
    return { success: false, error: 'todoId 是必填参数' }
  }
  if (action !== 'approve' && action !== 'reject') {
    return { success: false, error: `action 只能是 approve 或 reject，收到：${action}` }
  }

  const BASE = 'https://your-oa.example.com'

  try {
    const resp = await fetch(`${BASE}/api/todo/submit`, {
      method: 'POST',
      credentials: 'include',
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json'
      },
      body: JSON.stringify({
        todoId,
        decision: action,         // approve | reject
        comment: memo
      })
    })

    if (!resp.ok) {
      const text = await resp.text()
      return {
        success: false,
        todoId,
        status: resp.status,
        error: resp.status === 401
          ? '未登录或登录已过期'
          : `HTTP ${resp.status}: ${text.slice(0, 200)}`
      }
    }

    const data = await resp.json()

    // 业务层失败：HTTP 200 但 code 非 0
    if (data.code != null && data.code !== 0 && data.code !== '0') {
      return {
        success: false,
        todoId,
        error: data.message || data.msg || '审批接口返回业务失败'
      }
    }

    return {
      success: true,
      todoId,
      action,
      data: data.data || data
    }
  } catch (e) {
    return {
      success: false,
      todoId,
      error: e.message || String(e)
    }
  }
}
