// oa-approved-list — 拉取最近已审批列表（脱敏示例）
//
// 模式 A：API 代理型。只读接口，供数字人事后核对自动审批是否生效。

async (params) => {
  const { pageSize = 20, pageIndex = 1 } = params || {}

  const BASE = 'https://your-oa.example.com'

  try {
    const url = `${BASE}/api/todo/approved?pageSize=${pageSize}&pageIndex=${pageIndex}`
    const resp = await fetch(url, {
      method: 'GET',
      credentials: 'include',
      headers: { 'Accept': 'application/json' }
    })

    if (!resp.ok) {
      return {
        success: false,
        status: resp.status,
        error: resp.status === 401
          ? '未登录或登录已过期'
          : `HTTP ${resp.status}`
      }
    }

    const data = await resp.json()
    const approved = data.list || data.data?.records || data.records || []
    const total = data.total ?? data.data?.total ?? approved.length

    return {
      success: true,
      approved,
      total
    }
  } catch (e) {
    return {
      success: false,
      error: e.message || String(e)
    }
  }
}
