---
name: oa-approved-list
description: 拉取当前用户最近已审批的项目列表，用于核对自动审批是否真的生效。
---

# oa-approved-list

调用 OA 系统的"已审批列表"接口。用于在数字人执行完一轮自动审批后，
反向核对哪些 todoId 真的进入了已审批状态——没进入的说明接口异常或权限不足。

## 参数

| 参数 | 类型 | 默认 | 说明 |
|---|---|---|---|
| `pageSize` | number | `20` | 分页大小 |
| `pageIndex` | number | `1` | 页码 |

## 返回

```json
{
  "success": true,
  "approved": [
    { "id": "...", "title": "...", "decision": "approve", "approvedAt": "..." }
  ],
  "total": 17
}
```

## 脱敏说明

`https://your-oa.example.com/api/todo/approved` 是占位接口，请按真实 API 替换。
