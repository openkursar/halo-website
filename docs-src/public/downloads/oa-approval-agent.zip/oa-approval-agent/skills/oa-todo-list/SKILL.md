---
name: oa-todo-list
description: 拉取当前用户的 OA 待审批列表。借用浏览器已登录的 cookie 调用 OA 内部 API，可选拉取每一条的详情。
---

# oa-todo-list

调用 OA 系统的"待办列表"接口，返回当前登录用户名下所有等待审批的项目。

## 参数

| 参数 | 类型 | 默认 | 说明 |
|---|---|---|---|
| `pageSize` | number | `30` | 分页大小 |
| `pageIndex` | number | `1` | 页码（从 1 开始） |
| `withDetail` | boolean | `false` | 是否同时拉取每条待办的详情（金额、申请人、附件等） |

## 返回

成功：

```json
{
  "success": true,
  "todos": [
    {
      "id": "...",
      "title": "...",
      "applicant": "...",
      "category": "...",
      "createdAt": "...",
      "detail": { /* 仅 withDetail=true 时存在 */ }
    }
  ],
  "total": 42
}
```

失败：

```json
{
  "success": false,
  "status": 401,
  "error": "未登录或登录已过期"
}
```

## 脱敏说明

`https://your-oa.example.com/api/todo/list` 与 `/api/todo/detail/<id>` 是占位接口，
请替换为你公司 OA 的真实路径与字段名（`list`、`total`、`id`、`title` 等）。
