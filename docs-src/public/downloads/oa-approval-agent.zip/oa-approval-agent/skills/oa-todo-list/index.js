// oa-todo-list — 拉取 OA 待审批列表（脱敏示例）
//
// 模式 A：API 代理型 Browser Action
// 关键点：
//   - credentials: 'include'    复用浏览器登录 cookie
//   - try/catch + success/error 标准返回，让上游 AI 能稳定判断成败
//   - 不抛异常，所有错误都打包进返回值
//
// 把 your-oa.example.com 替换成你公司 OA 的真实域名，
// 把 /api/todo/list、/api/todo/detail/:id 替换成真实接口路径与字段名。

async (params) => {
  const {
    pageSize = 30,
    pageIndex = 1,
    withDetail = false
  } = params || {}

  const BASE = 'https://your-oa.example.com'

  try {
    // 1. 拉列表
    const listUrl = `${BASE}/api/todo/list?pageSize=${pageSize}&pageIndex=${pageIndex}`
    const resp = await fetch(listUrl, {
      method: 'GET',
      credentials: 'include',
      headers: { 'Accept': 'application/json' }
    })

    if (!resp.ok) {
      return {
        success: false,
        status: resp.status,
        error: resp.status === 401
          ? '未登录或登录已过期，请重新打开 OA 登录后再触发'
          : `HTTP ${resp.status}`
      }
    }

    const data = await resp.json()

    // 兼容常见返回结构：{ list: [...], total: N } 或 { data: { records: [...] } }
    const todos = data.list || data.data?.records || data.records || []
    const total = data.total ?? data.data?.total ?? todos.length

    // 2. 可选：拉每条详情（注意：详情接口可能限流，必要时改为按需拉）
    if (withDetail && todos.length > 0) {
      for (const todo of todos) {
        try {
          const detailResp = await fetch(`${BASE}/api/todo/detail/${todo.id}`, {
            method: 'GET',
            credentials: 'include',
            headers: { 'Accept': 'application/json' }
          })
          if (detailResp.ok) {
            const detailData = await detailResp.json()
            todo.detail = detailData.data || detailData
          } else {
            todo.detail = { _error: `HTTP ${detailResp.status}` }
          }
        } catch (e) {
          todo.detail = { _error: e.message || String(e) }
        }
      }
    }

    return {
      success: true,
      todos,
      total
    }
  } catch (e) {
    return {
      success: false,
      error: e.message || String(e)
    }
  }
}
