# OA 审批助手（脱敏示例）

这是 Halo 数字人 App 的**参考案例**，演示「模式 A：API 代理型」
Browser Action 在企业内部系统自动化中的标准写法。

> 配套教程：[教程：做一个浏览器自动化数字人](https://hello-halo.cc/docs/developers/digital-humans/build.html)

## ⚠️ 这是脱敏案例，不能直接运行

所有 URL、API 路径、字段名都是占位符。你需要：

1. 把它当作模板和参考
2. 把所有 `your-oa.example.com` 替换为你公司 OA 的真实地址
3. 根据自己 OA 的 API 结构调整 `index.js` 里的请求路径、字段名、提交方式
4. 在数字人「工作动态」上方的提示里点「打开并登录」，登录一次你的 OA

如果你的 OA API 结构差别很大，建议用「路 A：让 AI 帮你改」——把这个文件夹整个路径贴给 Halo，让它读完之后帮你改造。

## 目录结构

```
oa-approval-agent/
├── spec.yaml                   ← 数字人主清单
├── README.md
└── skills/
    ├── oa-todo-list/           ← Browser Action：查待审批列表
    │   ├── SKILL.md
    │   └── index.js
    ├── oa-approve/             ← Browser Action：执行审批
    │   ├── SKILL.md
    │   └── index.js
    └── oa-approved-list/       ← Browser Action：查已审批列表（核对用）
        ├── SKILL.md
        └── index.js
```

## 安装

1. 解压本压缩包，得到 `oa-approval-agent/` 文件夹
2. 在 Halo 中打开「数字人」，点「创建数字人」→「导入」，把整个文件夹（或这个 .zip）拖进去
3. 在「能力与设置」里按需填写自动同意/拒绝关键词
4. 在数字人「工作动态」上方的提示里点「打开并登录」，登录你公司的 OA
5. 点「立即运行」，在「工作动态」里确认接口是否能通

## 你要改的 4 处地方

| 位置 | 改成什么 |
|---|---|
| `spec.yaml` 中的 `browser_login.url` | 你公司 OA 真实地址 |
| `skills/*/index.js` 中的 `BASE` 常量 | 同上 |
| `skills/*/index.js` 中的接口路径（`/api/todo/list` 等） | 你公司 OA 的真实接口 |
| `skills/*/index.js` 中的字段名（`todoId / decision / comment`）| 你公司 OA 的真实字段名 |

抓包定位接口的方法：打开 OA 的待办页 → F12 → Network → XHR/Fetch → 操作一次审批 → 看请求 URL、Method、Payload。

## 安全提示

- 默认 `auto_approve` 为 `false`：数字人只在报告里给出「建议同意 / 建议拒绝」，不会真的审批
- 即使启用自动审批，`max_approvals_per_run` 默认上限 10 条，防止规则失误时批量误操作
- 数字人会把已处理 ID 写入 `memory.processed_todos`，避免下次重复操作
- 建议先把关键词配置成**很窄**的范围（例如只匹配特定标题前缀），跑两轮稳定后再放宽

## License

MIT
